
angular.module('convopal', [])
.controller('MainController', [
'$scope',
function($scope) {
    $scope.username = 'Ali';
}]);