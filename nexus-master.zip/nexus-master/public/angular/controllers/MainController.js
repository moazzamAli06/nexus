convopal
.controller('MainController',
function($scope) {
	$scope.username = "Ali";
//$location.replace();
});